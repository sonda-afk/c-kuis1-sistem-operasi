// Library
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Set maxsize
#define maxsize 100

// Variabel string
char str[maxsize];

// Jumlah kata
int n, m;

// Var menu 
int menu;

// Var iterasi
int i;

// Prosedur membaca file
void readFile(char fileName[], char c, char s[]);